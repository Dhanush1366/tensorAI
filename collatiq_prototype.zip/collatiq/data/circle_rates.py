"""
Circle rate database (₹/sqft) — representative values per city/locality.
In production this would be a database seeded from state govt notifications.
"""

# Structure: city -> locality_keyword -> (residential, commercial) ₹/sqft
CIRCLE_RATES = {
    "mumbai": {
        "bandra":         (18000, 32000),
        "andheri":        (12000, 22000),
        "juhu":           (22000, 38000),
        "borivali":       (9000,  16000),
        "thane":          (7500,  13000),
        "dadar":          (15000, 27000),
        "lower parel":    (19000, 34000),
        "powai":          (11000, 19000),
        "default":        (10000, 18000),
    },
    "pune": {
        "koregaon park":  (8500,  15000),
        "kalyani nagar":  (7800,  13500),
        "baner":          (6500,  11500),
        "hinjewadi":      (5500,  10000),
        "kothrud":        (7000,  12000),
        "viman nagar":    (7200,  12500),
        "hadapsar":       (5000,  9000),
        "wakad":          (5800,  10500),
        "default":        (5500,  9500),
    },
    "bangalore": {
        "whitefield":     (6500,  12000),
        "indiranagar":    (9500,  17000),
        "koramangala":    (10500, 18500),
        "hsr layout":     (8000,  14000),
        "electronic city":(4500,  8500),
        "jayanagar":      (9000,  16000),
        "hebbal":         (6000,  11000),
        "sarjapur":       (5000,  9000),
        "default":        (6000,  11000),
    },
    "hyderabad": {
        "banjara hills":  (8500,  15000),
        "jubilee hills":  (9000,  16000),
        "gachibowli":     (6500,  12000),
        "hitech city":    (7000,  13000),
        "kondapur":       (5500,  10000),
        "madhapur":       (6000,  11000),
        "default":        (5000,  9000),
    },
    "delhi": {
        "south delhi":    (15000, 27000),
        "dwarka":         (7000,  12500),
        "rohini":         (6500,  11500),
        "lajpat nagar":   (14000, 25000),
        "vasant kunj":    (12000, 22000),
        "noida":          (5500,  10000),
        "gurgaon":        (7500,  13500),
        "default":        (8000,  14000),
    },
    "chennai": {
        "t nagar":        (10000, 18000),
        "adyar":          (9000,  16000),
        "anna nagar":     (8500,  15000),
        "velachery":      (6000,  11000),
        "omr":            (5000,  9000),
        "porur":          (5500,  10000),
        "default":        (5500,  9500),
    },
    "default": {
        "default":        (4000,  7500),
    },
}

# Infrastructure scores by city tier
CITY_TIER = {
    "mumbai": 1, "delhi": 1, "bangalore": 1, "hyderabad": 1,
    "pune": 2, "chennai": 2, "kolkata": 2, "ahmedabad": 2,
    "jaipur": 3, "lucknow": 3, "nagpur": 3, "indore": 3,
}

def get_circle_rate(city: str, locality: str, is_commercial: bool) -> int:
    """Return circle rate ₹/sqft for the given location."""
    city_lower = city.lower().strip()
    loc_lower  = locality.lower().strip()
    idx = 1 if is_commercial else 0

    city_data = CIRCLE_RATES.get(city_lower, CIRCLE_RATES["default"])
    for key, rates in city_data.items():
        if key != "default" and key in loc_lower:
            return rates[idx]
    return city_data.get("default", CIRCLE_RATES["default"]["default"])[idx]

def get_city_tier(city: str) -> int:
    return CITY_TIER.get(city.lower().strip(), 3)
