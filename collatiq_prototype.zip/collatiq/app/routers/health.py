from fastapi import APIRouter
from app.models import HealthResponse
from app.data.locality_db import CIRCLE_RATES

router = APIRouter(tags=["Health"])

@router.get("/health", response_model=HealthResponse)
def health():
    return HealthResponse(
        status="ok",
        version="1.0.0",
        cities_supported=len(CIRCLE_RATES) - 1,
        message="CollatIQ is up and running."
    )
