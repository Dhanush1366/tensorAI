"""
CollatIQ — Valuation Router
POST /api/v1/valuate         — Main valuation endpoint
GET  /api/v1/valuate/example — Run a built-in example
GET  /api/v1/valuate/cities  — Supported cities & tiers
GET  /api/v1/valuate/compare — Compare two properties
"""

from fastapi import APIRouter, HTTPException, Query
from typing import Optional
from app.models import ValuationRequest, ValuationResponse, PropertyType, SubType, LegalStatus, OccupancyStatus
from app.fraud import fraud_detector
from app.engine import valuation_engine
import time

router = APIRouter(tags=["Valuation"])


def _run_pipeline(req: ValuationRequest) -> dict:
    """Core pipeline: fraud check → valuation → response."""
    t0 = time.time()
    cleaned_req, fraud_flags, confidence_penalty = fraud_detector.run(req)
    result = valuation_engine.valuate(cleaned_req, fraud_flags, confidence_penalty)
    elapsed_ms = round((time.time() - t0) * 1000, 1)
    return result, elapsed_ms


@router.post(
    "/valuate",
    response_model=ValuationResponse,
    summary="Valuate a Property",
    description="""
Submit a property's details and receive a full collateral intelligence report including:
- Market value range (₹)
- Distress sale value range (₹)
- Resale Potential Index (0–100)
- Time to liquidate (days range)
- Confidence score (0–1)
- Key drivers and risk flags
- Fraud/validation flags (if any)

**All inputs pass through a fraud-detection layer before entering the valuation model.**
    """,
    responses={
        200: {"description": "Successful valuation"},
        422: {"description": "Validation error in request body"},
    }
)
async def valuate_property(req: ValuationRequest):
    try:
        result, elapsed_ms = _run_pipeline(req)
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Valuation engine error: {str(e)}")


@router.get(
    "/valuate/example",
    response_model=ValuationResponse,
    summary="Run Example Valuation",
    description="Returns a sample valuation for a 2BHK apartment in Koregaon Park, Pune. Great for testing."
)
async def example_valuation():
    example = ValuationRequest(
        address="Koregaon Park, Pune, Maharashtra",
        city="Pune",
        lat=18.5362,
        lng=73.8938,
        property_type=PropertyType.residential,
        sub_type=SubType.apartment,
        carpet_area_sqft=850,
        vintage_years=8,
        floor=4,
        total_floors=12,
        lift_available=True,
        parking_available=True,
        legal_status=LegalStatus.freehold,
        occupancy=OccupancyStatus.rented,
        monthly_rent_inr=28000,
        near_metro=True,
        near_school=True,
        planned_area=True,
    )
    result, _ = _run_pipeline(example)
    return result


@router.get(
    "/valuate/cities",
    summary="Supported Cities & Circle Rates",
    description="Returns all cities with pre-loaded circle rate data and their tier structure."
)
async def supported_cities():
    from app.data.locality_db import CIRCLE_RATES
    return {
        "cities": [c for c in CIRCLE_RATES.keys() if c != "default"],
        "note": "For cities not listed, the engine uses a calibrated default. Provide lat/lng for best results.",
        "tier_description": {
            "prime":   "Top micro-markets (Koregaon Park, Bandra, Indiranagar etc.)",
            "good":    "Well-established areas with decent demand",
            "average": "Mid-market localities",
            "fringe":  "Developing or peripheral areas",
        }
    }


@router.post(
    "/valuate/compare",
    summary="Compare Two Properties",
    description="Submit two properties and get a side-by-side comparison of their valuations."
)
async def compare_properties(prop_a: ValuationRequest, prop_b: ValuationRequest):
    result_a, ms_a = _run_pipeline(prop_a)
    result_b, ms_b = _run_pipeline(prop_b)

    better_value     = "A" if result_a.market_value_range[0] > result_b.market_value_range[0] else "B"
    better_liquidity = "A" if result_a.resale_potential_index > result_b.resale_potential_index else "B"
    better_confidence= "A" if result_a.confidence_score > result_b.confidence_score else "B"

    return {
        "property_a": result_a,
        "property_b": result_b,
        "comparison_summary": {
            "higher_market_value":   better_value,
            "higher_liquidity":      better_liquidity,
            "higher_confidence":     better_confidence,
            "rpi_difference":        result_a.resale_potential_index - result_b.resale_potential_index,
            "value_gap_inr":         result_a.market_value_range[0] - result_b.market_value_range[0],
            "recommendation": (
                f"Property {better_liquidity} offers better exit certainty. "
                f"Property {better_value} commands higher market value."
            )
        }
    }
