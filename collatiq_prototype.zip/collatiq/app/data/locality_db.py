"""
CollatIQ — Locality & Circle Rate Database
Structured reference data for 50+ Indian micro-markets.
In production this would connect to state government APIs.
"""

from typing import Dict, Tuple

# ── Circle rates ₹/sqft by city → locality tier ──────────────────────────────
# Format: { city: { tier: circle_rate_psf } }
CIRCLE_RATES: Dict[str, Dict[str, int]] = {
    "Mumbai": {
        "prime":    25000,  # Bandra, Juhu, Worli
        "good":     15000,  # Andheri, Powai, Goregaon
        "average":   8000,  # Thane, Navi Mumbai
        "fringe":    4500,
    },
    "Delhi": {
        "prime":    20000,  # GK, Vasant Vihar, Defence Colony
        "good":     10000,  # Rohini, Dwarka, Janakpuri
        "average":   6000,
        "fringe":    3500,
    },
    "Bengaluru": {
        "prime":    12000,  # Indiranagar, Koramangala, Whitefield
        "good":      7500,  # HSR, JP Nagar, Hebbal
        "average":   4500,
        "fringe":    2800,
    },
    "Pune": {
        "prime":     9500,  # Koregaon Park, Kalyani Nagar
        "good":      6000,  # Baner, Kothrud, Wakad
        "average":   3800,
        "fringe":    2200,
    },
    "Hyderabad": {
        "prime":     9000,  # Jubilee Hills, Banjara Hills
        "good":      5500,  # Gachibowli, HITEC City
        "average":   3500,
        "fringe":    2000,
    },
    "Chennai": {
        "prime":    10000,  # Adyar, Alwarpet, Nungambakkam
        "good":      6000,  # Anna Nagar, OMR, Velachery
        "average":   3800,
        "fringe":    2200,
    },
    "Kolkata": {
        "prime":     8000,
        "good":      4500,
        "average":   2800,
        "fringe":    1800,
    },
    "Ahmedabad": {
        "prime":     6500,
        "good":      4000,
        "average":   2500,
        "fringe":    1500,
    },
    "Noida": {
        "prime":     7500,
        "good":      5000,
        "average":   3200,
        "fringe":    2000,
    },
    "Gurgaon": {
        "prime":    12000,
        "good":      7000,
        "average":   4500,
        "fringe":    2800,
    },
    "default": {
        "prime":     6000,
        "good":      3500,
        "average":   2200,
        "fringe":    1400,
    },
}

# ── Prime locality keywords → city ───────────────────────────────────────────
PRIME_LOCALITY_KEYWORDS: Dict[str, str] = {
    # Mumbai
    "bandra": "Mumbai", "juhu": "Mumbai", "worli": "Mumbai",
    "parel": "Mumbai", "lower parel": "Mumbai", "powai": "Mumbai",
    # Delhi
    "greater kailash": "Delhi", "vasant vihar": "Delhi", "defence colony": "Delhi",
    "south extension": "Delhi", "golf links": "Delhi",
    # Bengaluru
    "indiranagar": "Bengaluru", "koramangala": "Bengaluru", "whitefield": "Bengaluru",
    "hsr layout": "Bengaluru", "jp nagar": "Bengaluru", "hebbal": "Bengaluru",
    # Pune
    "koregaon park": "Pune", "kalyani nagar": "Pune", "baner": "Pune",
    "kothrud": "Pune", "wakad": "Pune", "hinjewadi": "Pune", "viman nagar": "Pune",
    # Hyderabad
    "jubilee hills": "Hyderabad", "banjara hills": "Hyderabad",
    "gachibowli": "Hyderabad", "hitec city": "Hyderabad",
    # Chennai
    "adyar": "Chennai", "alwarpet": "Chennai", "nungambakkam": "Chennai",
    "anna nagar": "Chennai", "omr": "Chennai",
    # Kolkata
    "park street": "Kolkata", "ballygunge": "Kolkata", "salt lake": "Kolkata",
    # Gurgaon
    "golf course": "Gurgaon", "dlf": "Gurgaon", "sohna": "Gurgaon",
}

GOOD_LOCALITY_KEYWORDS: set = {
    "andheri", "goregaon", "malad", "thane",           # Mumbai
    "rohini", "dwarka", "janakpuri", "saket",           # Delhi
    "electronic city", "bannerghatta", "yelahanka",     # Bengaluru
    "hadapsar", "magarpatta", "kondhwa", "pimpri",      # Pune
    "kukatpally", "ameerpet", "lb nagar",               # Hyderabad
    "velachery", "porur", "pallavaram",                 # Chennai
    "sector 18", "sector 62", "sector 137",             # Noida
    "sushant lok", "sector 56",                         # Gurgaon
}

# ── Infrastructure proximity multipliers ────────────────────────────────────
INFRA_MULTIPLIERS = {
    "near_metro":    0.08,   # +8% value premium
    "near_highway":  0.04,
    "near_hospital": 0.03,
    "near_school":   0.03,
    "planned_area":  0.06,
}

# ── Depreciation curve by vintage ────────────────────────────────────────────
def depreciation_factor(vintage_years: int) -> Tuple[float, str]:
    """Returns (depreciation_factor, vintage_label)."""
    if vintage_years <= 5:
        return 1.00, "new"
    elif vintage_years <= 10:
        return 0.93, "mid_new"
    elif vintage_years <= 15:
        return 0.85, "mid_age"
    elif vintage_years <= 25:
        return 0.75, "old"
    elif vintage_years <= 40:
        return 0.62, "very_old"
    else:
        return 0.50, "dilapidated"

# ── Property type base adjustments ───────────────────────────────────────────
# Multiplier vs residential apartment baseline
PROPERTY_TYPE_ADJUSTMENTS = {
    ("residential", "apartment"):  1.00,
    ("residential", "villa"):      1.25,
    ("residential", "bungalow"):   1.20,
    ("residential", "plot"):       0.90,   # plots have different dynamics
    ("commercial",  "shop"):       1.10,
    ("commercial",  "office"):     1.05,
    ("industrial",  "warehouse"):  0.75,
}

# ── Distress discount matrix ─────────────────────────────────────────────────
# { property_type: { locality_tier: discount_pct } }
DISTRESS_DISCOUNTS = {
    "residential": {
        "prime":   0.18,   # 18%
        "good":    0.22,
        "average": 0.28,
        "fringe":  0.35,
    },
    "commercial": {
        "prime":   0.22,
        "good":    0.28,
        "average": 0.33,
        "fringe":  0.40,
    },
    "industrial": {
        "prime":   0.28,
        "good":    0.33,
        "average": 0.38,
        "fringe":  0.45,
    },
}

# ── Liquidity / size norms by city tier ──────────────────────────────────────
# Typical carpet area ranges in sqft per sub-type
SIZE_NORMS_SQFT = {
    "apartment":  (200,  4000),
    "villa":      (800,  8000),
    "bungalow":   (1000, 10000),
    "plot":       (500,  20000),
    "shop":       (100,  5000),
    "office":     (200,  20000),
    "warehouse":  (1000, 100000),
}

# ── Metro cities with better market activity ─────────────────────────────────
METRO_CITIES = {
    "Mumbai", "Delhi", "Bengaluru", "Hyderabad",
    "Chennai", "Pune", "Gurgaon", "Noida", "Kolkata"
}

# ── Standard config bonus (fungible assets command higher RPI) ───────────────
STANDARD_CONFIGS = {
    ("residential", "apartment"): True,
    ("commercial",  "shop"):      True,
}
