"""CollatIQ — Fraud Detection Engine"""

from typing import List, Tuple
from app.models import ValuationRequest, FraudFlag, FraudSeverity, PropertyType, LegalStatus
from app.data.locality_db import SIZE_NORMS_SQFT


class FraudDetector:
    def run(self, req: ValuationRequest) -> Tuple[ValuationRequest, List[FraudFlag], float]:
        flags: List[FraudFlag] = []
        confidence_penalty = 0.0
        for check in [self._check_size, self._check_type_mismatch,
                      self._check_legal, self._check_config_plausibility,
                      self._check_floor_vs_total]:
            f, p = check(req)
            flags.extend(f); confidence_penalty += p
        return req, flags, min(confidence_penalty, 0.40)

    def _check_size(self, req):
        flags, pen = [], 0.0
        sub = req.sub_type.value
        if sub not in SIZE_NORMS_SQFT:
            return flags, pen
        lo, hi = SIZE_NORMS_SQFT[sub]
        area = req.carpet_area_sqft
        if area > hi:
            sev = FraudSeverity.high if area > hi * 1.5 else FraudSeverity.medium
            flags.append(FraudFlag(code="SIZE_OVERSTATED", severity=sev,
                description=f"Carpet area {area:.0f} sqft exceeds P99 norm of {hi} sqft for {sub}.",
                action_taken=f"Confidence reduced. Value capped at {hi} sqft equivalent."))
            pen += 0.20 if sev == FraudSeverity.high else 0.10
        elif area < lo:
            flags.append(FraudFlag(code="SIZE_UNDERSTATED", severity=FraudSeverity.low,
                description=f"Carpet area {area:.0f} sqft below typical minimum {lo} sqft for {sub}.",
                action_taken="Flagged for review. Valuation computed with stated area."))
            pen += 0.05
        return flags, pen

    def _check_type_mismatch(self, req):
        flags, pen = [], 0.0
        addr = req.address.lower()
        industrial_kw = {"industrial estate", "midc", "industrial area", "factory"}
        residential_kw = {"society", "residency", "heights", "apartments", "nagar", "vihar"}
        if req.property_type == PropertyType.residential:
            if any(kw in addr for kw in industrial_kw):
                flags.append(FraudFlag(code="TYPE_LOCATION_MISMATCH", severity=FraudSeverity.high,
                    description="Address has industrial keywords but type is residential.",
                    action_taken="Risk flag added. Lender should verify."))
                pen += 0.15
        if req.property_type == PropertyType.industrial:
            if any(kw in addr for kw in residential_kw):
                flags.append(FraudFlag(code="TYPE_LOCATION_MISMATCH", severity=FraudSeverity.medium,
                    description="Address suggests residential locality but type is industrial.",
                    action_taken="Distress discount increased by 5%."))
                pen += 0.10
        return flags, pen

    def _check_legal(self, req):
        flags, pen = [], 0.0
        if req.legal_status == LegalStatus.leasehold:
            remaining = req.lease_years_remaining or 30
            if remaining < 15:
                flags.append(FraudFlag(code="LEASE_SHORT_TENURE", severity=FraudSeverity.high,
                    description=f"Leasehold with only {remaining} years remaining.",
                    action_taken="Distress discount +15%. RPI reduced 25 pts."))
                pen += 0.20
            elif remaining < 30:
                flags.append(FraudFlag(code="LEASE_MEDIUM_TENURE", severity=FraudSeverity.medium,
                    description=f"Leasehold with {remaining} years remaining.",
                    action_taken="Distress discount +8%. RPI reduced 12 pts."))
                pen += 0.10
        return flags, pen

    def _check_config_plausibility(self, req):
        flags, pen = [], 0.0
        area = req.carpet_area_sqft
        sub = req.sub_type.value
        implausible, msg = False, ""
        if sub == "apartment" and area < 150:
            implausible, msg = True, f"Apartment {area:.0f} sqft is implausibly small."
        elif sub == "apartment" and area > 8000:
            implausible, msg = True, f"Apartment {area:.0f} sqft is unusually large."
        elif sub == "shop" and area > 10000:
            implausible, msg = True, f"Shop {area:.0f} sqft exceeds typical retail unit."
        elif sub == "plot" and area < 50:
            implausible, msg = True, f"Plot {area:.0f} sqft below minimum norms."
        if implausible:
            flags.append(FraudFlag(code="CONFIG_IMPLAUSIBLE", severity=FraudSeverity.medium,
                description=msg, action_taken="Confidence -10%. Manual review recommended."))
            pen += 0.10
        return flags, pen

    def _check_floor_vs_total(self, req):
        flags, pen = [], 0.0
        if req.floor is not None and req.total_floors is not None:
            if req.floor > req.total_floors:
                flags.append(FraudFlag(code="FLOOR_EXCEEDS_TOTAL", severity=FraudSeverity.medium,
                    description=f"Floor {req.floor} > total floors {req.total_floors}.",
                    action_taken="Floor data ignored. Confidence reduced."))
                pen += 0.05
        return flags, pen


fraud_detector = FraudDetector()
