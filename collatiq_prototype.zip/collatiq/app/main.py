"""
CollatIQ — AI-Powered Collateral Valuation & Resale Liquidity Engine
FastAPI Application Entry Point
"""

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
import time

from app.routers import valuate, health
from app.config import settings

app = FastAPI(
    title="CollatIQ API",
    description="""
## CollatIQ — Collateral Valuation & Resale Liquidity Engine

A market-aware collateral intelligence layer for NBFCs and secured lenders.

### What It Does
Given a property's address, type, size, and age — CollatIQ returns:
- **Estimated Market Value** (₹ range)
- **Distress Sale Value** (₹ range)  
- **Resale Potential Index** (0–100)
- **Time to Liquidate** (days range)
- **Confidence Score** (0.0–1.0)
- **Key Drivers & Risk Flags** (explainability)

### Fraud Safeguards
Every request passes through input validation before entering the valuation pipeline:
- Size sanity checks against locality norms
- Location–property type mismatch detection
- Legal encumbrance proxy flags
- Configuration plausibility checks
    """,
    version="1.0.0",
    contact={"name": "CollatIQ Team", "email": "team@collatiq.dev"},
    license_info={"name": "MIT"},
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.middleware("http")
async def add_process_time(request: Request, call_next):
    start = time.time()
    response = await call_next(request)
    response.headers["X-Process-Time-Ms"] = str(round((time.time() - start) * 1000, 1))
    return response

app.include_router(health.router)
app.include_router(valuate.router, prefix="/api/v1")

@app.get("/", response_class=HTMLResponse, include_in_schema=False)
async def root():
    return """
<!DOCTYPE html>
<html>
<head>
  <title>CollatIQ API</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { font-family: 'Segoe UI', system-ui, sans-serif; background: #0A1628; color: #fff; min-height: 100vh; }
    .hero { padding: 60px 40px 40px; max-width: 900px; margin: 0 auto; }
    .badge { display: inline-block; background: #0D7377; color: #fff; font-size: 11px; font-weight: 700;
             padding: 4px 12px; border-radius: 4px; letter-spacing: 1px; margin-bottom: 20px; }
    h1 { font-size: 56px; font-weight: 800; color: #F0A500; line-height: 1.1; margin-bottom: 8px; }
    .sub { font-size: 20px; color: #14BDAC; margin-bottom: 12px; }
    .desc { font-size: 15px; color: #7A8FA6; max-width: 600px; line-height: 1.6; margin-bottom: 40px; }
    .cards { display: grid; grid-template-columns: repeat(auto-fit, minmax(260px, 1fr)); gap: 16px; margin-bottom: 40px; }
    .card { background: #102244; border-radius: 10px; padding: 20px; border-left: 4px solid #0D7377; }
    .card h3 { color: #F0A500; font-size: 13px; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 8px; }
    .card p { color: #AABBD0; font-size: 13px; line-height: 1.5; }
    .btns { display: flex; gap: 12px; flex-wrap: wrap; }
    .btn { display: inline-block; padding: 12px 24px; border-radius: 6px; font-weight: 700;
           font-size: 14px; text-decoration: none; transition: opacity 0.2s; }
    .btn:hover { opacity: 0.85; }
    .btn-primary { background: #0D7377; color: #fff; }
    .btn-secondary { background: #F0A500; color: #0A1628; }
    .btn-ghost { background: transparent; color: #14BDAC; border: 1px solid #14BDAC; }
    .outputs { display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; margin: 30px 0; }
    .out-chip { background: #102244; border-radius: 6px; padding: 10px 14px; font-size: 12px; color: #C8D8EA; }
    .out-chip strong { display: block; color: #14BDAC; margin-bottom: 3px; }
    footer { text-align: center; padding: 30px; color: #3D5A80; font-size: 12px; border-top: 1px solid #102244; }
  </style>
</head>
<body>
  <div class="hero">
    <div class="badge">PROBLEM STATEMENT 4A · POONAWALLA FINCORP</div>
    <h1>CollatIQ</h1>
    <div class="sub">AI-Powered Collateral Valuation & Resale Liquidity Engine</div>
    <p class="desc">
      A market-aware intelligence layer for property-backed lending. 
      Submit a property — get market value, distress value, liquidity score, 
      time-to-liquidate, confidence, and risk flags — instantly.
    </p>

    <div class="outputs">
      <div class="out-chip"><strong>Market Value</strong>₹ Range</div>
      <div class="out-chip"><strong>Distress Value</strong>₹ Range</div>
      <div class="out-chip"><strong>Resale Index</strong>0–100</div>
      <div class="out-chip"><strong>Time to Sell</strong>Days Range</div>
      <div class="out-chip"><strong>Confidence</strong>0.0–1.0</div>
      <div class="out-chip"><strong>Risk Flags</strong>Explainability</div>
    </div>

    <div class="cards">
      <div class="card">
        <h3>🛡 Fraud-First Architecture</h3>
        <p>Every request passes 4 validation checks before entering the valuation pipeline. Size sanity, location plausibility, legal flags.</p>
      </div>
      <div class="card">
        <h3>📊 Range-Based Outputs</h3>
        <p>No false precision — every estimate is a min/max range with a calibrated confidence score reflecting actual uncertainty.</p>
      </div>
      <div class="card">
        <h3>⚡ Zero Proprietary Data</h3>
        <p>Runs on publicly derivable inputs and structured assumptions. No transaction datasets required. Deploy anywhere.</p>
      </div>
    </div>

    <div class="btns">
      <a href="/docs" class="btn btn-primary">📖 Interactive API Docs</a>
      <a href="/redoc" class="btn btn-secondary">📄 ReDoc Reference</a>
      <a href="/api/v1/valuate/example" class="btn btn-ghost">▶ Run Example</a>
    </div>
  </div>
  <footer>CollatIQ v1.0 · Built for Poonawalla Fincorp Hackathon · Problem Statement 4A</footer>
</body>
</html>
"""
