"""
CollatIQ — Data Models
Request and Response schemas with full validation
"""

from pydantic import BaseModel, Field, field_validator, model_validator
from typing import Optional, List, Tuple
from enum import Enum


class PropertyType(str, Enum):
    residential = "residential"
    commercial   = "commercial"
    industrial   = "industrial"

class SubType(str, Enum):
    apartment  = "apartment"
    villa      = "villa"
    plot       = "plot"
    shop       = "shop"
    office     = "office"
    warehouse  = "warehouse"
    bungalow   = "bungalow"

class LegalStatus(str, Enum):
    freehold  = "freehold"
    leasehold = "leasehold"
    unknown   = "unknown"

class OccupancyStatus(str, Enum):
    self_occupied = "self_occupied"
    rented        = "rented"
    vacant        = "vacant"

class LiquidityBand(str, Enum):
    highly_liquid = "Highly Liquid"
    moderate      = "Moderate Liquidity"
    illiquid      = "Illiquid / Specialised"

class FraudSeverity(str, Enum):
    low    = "LOW"
    medium = "MEDIUM"
    high   = "HIGH"


class ValuationRequest(BaseModel):
    address: str = Field(..., min_length=5, max_length=300, description="Full property address or locality name", examples=["Koregaon Park, Pune, Maharashtra"])
    city: str = Field(..., min_length=2, max_length=100, description="City name", examples=["Pune"])
    lat: Optional[float] = Field(None, ge=-90,  le=90)
    lng: Optional[float] = Field(None, ge=-180, le=180)
    property_type: PropertyType = Field(...)
    sub_type: SubType           = Field(...)
    carpet_area_sqft: float     = Field(..., gt=0, le=50000)
    vintage_years: int          = Field(..., ge=0, le=100)
    floor: Optional[int]                = Field(None, ge=0, le=80)
    total_floors: Optional[int]         = Field(None, ge=1, le=200)
    lift_available: Optional[bool]      = Field(None)
    parking_available: Optional[bool]   = Field(None)
    furnished_status: Optional[str]     = Field(None)
    legal_status: LegalStatus           = Field(LegalStatus.unknown)
    lease_years_remaining: Optional[int]= Field(None, ge=0, le=999)
    occupancy: OccupancyStatus          = Field(OccupancyStatus.vacant)
    monthly_rent_inr: Optional[float]   = Field(None, ge=0)
    near_metro: Optional[bool]          = Field(None)
    near_highway: Optional[bool]        = Field(None)
    near_hospital: Optional[bool]       = Field(None)
    near_school: Optional[bool]         = Field(None)
    planned_area: Optional[bool]        = Field(None)

    @field_validator("city")
    @classmethod
    def normalise_city(cls, v):
        return v.strip().title()

    @field_validator("address")
    @classmethod
    def normalise_address(cls, v):
        return v.strip()

    @model_validator(mode="after")
    def check_lease_leasehold(self):
        if self.legal_status == LegalStatus.leasehold and self.lease_years_remaining is None:
            self.lease_years_remaining = 30
        return self

    model_config = {
        "json_schema_extra": {
            "example": {
                "address": "Koregaon Park, Pune",
                "city": "Pune",
                "lat": 18.5362, "lng": 73.8938,
                "property_type": "residential",
                "sub_type": "apartment",
                "carpet_area_sqft": 850,
                "vintage_years": 8,
                "floor": 4,
                "total_floors": 12,
                "lift_available": True,
                "legal_status": "freehold",
                "occupancy": "rented",
                "monthly_rent_inr": 28000,
                "near_metro": True,
                "planned_area": True,
            }
        }
    }


class FraudFlag(BaseModel):
    code: str
    severity: FraudSeverity
    description: str
    action_taken: str


class ValuationResponse(BaseModel):
    market_value_range: Tuple[int, int]
    distress_value_range: Tuple[int, int]
    resale_potential_index: int = Field(..., ge=0, le=100)
    liquidity_band: LiquidityBand
    time_to_sell_days: Tuple[int, int]
    confidence_score: float = Field(..., ge=0, le=1)
    key_drivers: List[str]
    risk_flags: List[str]
    fraud_flags: List[FraudFlag] = Field(default_factory=list)
    price_per_sqft: int
    circle_rate_benchmark_psf: int
    rental_yield_pct: Optional[float] = None
    distress_discount_pct: float
    valuation_methodology: str
    disclaimer: str = (
        "AI-generated estimate for indicative purposes only. "
        "Does not constitute a formal valuation report."
    )


class HealthResponse(BaseModel):
    status: str
    version: str
    cities_supported: int
    message: str
