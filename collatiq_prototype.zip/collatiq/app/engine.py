"""CollatIQ — Valuation & Liquidity Engine"""

from typing import List, Tuple
from app.models import (
    ValuationRequest, ValuationResponse, FraudFlag,
    LiquidityBand, PropertyType, LegalStatus, OccupancyStatus
)
from app.data.locality_db import (
    CIRCLE_RATES, PRIME_LOCALITY_KEYWORDS, GOOD_LOCALITY_KEYWORDS,
    INFRA_MULTIPLIERS, PROPERTY_TYPE_ADJUSTMENTS, DISTRESS_DISCOUNTS,
    METRO_CITIES, STANDARD_CONFIGS, depreciation_factor,
)


class ValuationEngine:

    def valuate(self, req, fraud_flags, confidence_penalty):
        drivers, risk_flags_out = [], []

        # Step 1: Locality
        city, tier, circle_rate_psf = self._resolve_locality(req, drivers, risk_flags_out)

        # Step 2: Base value
        area = min(req.carpet_area_sqft, 50000)
        base_value = circle_rate_psf * area
        pt_key = (req.property_type.value, req.sub_type.value)
        pt_mult = PROPERTY_TYPE_ADJUSTMENTS.get(pt_key, 1.0)
        base_value *= pt_mult
        if pt_mult > 1.0:
            drivers.append(f"{req.sub_type.value}_premium")
        elif pt_mult < 0.9:
            risk_flags_out.append(f"{req.sub_type.value}_lower_demand")

        # Step 3: Infra premium
        infra_mult = 1.0
        for attr, premium in INFRA_MULTIPLIERS.items():
            if getattr(req, attr, None) is True:
                infra_mult += premium
                drivers.append(attr.replace("near_", "proximity_to_"))
        base_value *= infra_mult

        # Step 4: Depreciation
        dep_factor, vintage_label = depreciation_factor(req.vintage_years)
        base_value *= dep_factor
        if req.vintage_years <= 5:
            drivers.append("new_construction_premium")
        elif req.vintage_years > 15:
            risk_flags_out.append(f"age_{req.vintage_years}yr_depreciation")

        # Step 5: Rental yield
        rental_yield_pct = None
        if req.monthly_rent_inr and req.monthly_rent_inr > 0:
            rental_yield_pct = round((req.monthly_rent_inr * 12) / base_value * 100, 2)
            if rental_yield_pct >= 3.0:
                drivers.append(f"strong_rental_yield_{rental_yield_pct}pct")
                base_value *= 1.05
            elif rental_yield_pct >= 1.5:
                drivers.append(f"rental_yield_{rental_yield_pct}pct")
            else:
                risk_flags_out.append(f"low_rental_yield_{rental_yield_pct}pct")

        if req.occupancy == OccupancyStatus.rented:
            drivers.append("income_generating_asset")
        elif req.occupancy == OccupancyStatus.vacant:
            risk_flags_out.append("vacant_property_lower_liquidity")

        # Step 6: Floor & parking
        floor_mult = 1.0
        if (req.floor is not None and req.total_floors is not None
                and req.floor <= req.total_floors and req.lift_available):
            rel = req.floor / max(req.total_floors, 1)
            if rel >= 0.7:
                floor_mult = 1.04; drivers.append("high_floor_premium")
            elif req.floor == 0:
                floor_mult = 0.97; risk_flags_out.append("ground_floor_slight_discount")
        base_value *= floor_mult
        if req.parking_available:
            base_value *= 1.02; drivers.append("parking_availability_premium")

        # Step 7: Market value range
        spread = 0.10 if tier in ("prime", "good") else 0.13
        market_value_min = int(base_value * (1 - spread / 2))
        market_value_max = int(base_value * (1 + spread / 2))
        price_per_sqft   = int(base_value / area)

        # Step 8: Distress value
        discount_map = DISTRESS_DISCOUNTS.get(req.property_type.value, DISTRESS_DISCOUNTS["residential"])
        base_discount = discount_map.get(tier, 0.28)
        if req.legal_status == LegalStatus.leasehold:
            remaining = req.lease_years_remaining or 30
            if remaining < 15:   base_discount += 0.15
            elif remaining < 30: base_discount += 0.08
        distress_mid     = base_value * (1 - base_discount)
        distress_val_min = int(distress_mid * 0.95)
        distress_val_max = int(distress_mid * 1.05)

        # Step 9: RPI
        rpi = self._compute_rpi(req, tier, vintage_label, rental_yield_pct, city)
        liquidity_band = (LiquidityBand.highly_liquid if rpi >= 75
                          else LiquidityBand.moderate if rpi >= 50
                          else LiquidityBand.illiquid)

        # Step 10: Time to liquidate
        t_min, t_max = self._time_to_liquidate(rpi, req.property_type.value, city)

        # Step 11: Confidence
        base_conf = self._base_confidence(req, tier, city)
        confidence = max(0.35, round(base_conf - confidence_penalty, 2))

        # Step 12: Legal risk flags
        if req.legal_status == LegalStatus.leasehold:
            risk_flags_out.append("leasehold_limits_resale_pool")
        elif req.legal_status == LegalStatus.unknown:
            risk_flags_out.append("legal_status_unverified")

        methodology = (
            f"circle_rate({circle_rate_psf}₹/sqft) × area({area:.0f}sqft) × "
            f"type({pt_mult:.2f}) × infra({infra_mult:.2f}) × dep({dep_factor:.2f})"
        )

        return ValuationResponse(
            market_value_range=(market_value_min, market_value_max),
            distress_value_range=(distress_val_min, distress_val_max),
            resale_potential_index=rpi,
            liquidity_band=liquidity_band,
            time_to_sell_days=(t_min, t_max),
            confidence_score=confidence,
            key_drivers=drivers[:6],
            risk_flags=risk_flags_out[:5],
            fraud_flags=fraud_flags,
            price_per_sqft=price_per_sqft,
            circle_rate_benchmark_psf=circle_rate_psf,
            rental_yield_pct=rental_yield_pct,
            distress_discount_pct=round(base_discount * 100, 1),
            valuation_methodology=methodology,
        )

    def _resolve_locality(self, req, drivers, risk_flags):
        city_key = req.city if req.city in CIRCLE_RATES else "default"
        addr_lower = req.address.lower()
        tier = "average"
        matched_city = city_key
        for keyword, kw_city in PRIME_LOCALITY_KEYWORDS.items():
            if keyword in addr_lower:
                tier = "prime"
                if kw_city in CIRCLE_RATES:
                    matched_city = kw_city
                drivers.append(f"prime_{keyword.replace(' ','_')}_location")
                break
        else:
            for keyword in GOOD_LOCALITY_KEYWORDS:
                if keyword in addr_lower:
                    tier = "good"
                    drivers.append(f"good_locality_{keyword.replace(' ','_')}")
                    break
        if req.city in METRO_CITIES:
            if tier == "average": tier = "good"
            drivers.append("metro_city_liquidity_premium")
        city_rates = CIRCLE_RATES.get(matched_city, CIRCLE_RATES["default"])
        circle_rate_psf = city_rates[tier]
        if tier == "fringe":
            risk_flags.append("fringe_location_lower_demand")
        return matched_city, tier, circle_rate_psf

    def _compute_rpi(self, req, tier, vintage_label, rental_yield_pct, city):
        score = 50
        score += {"prime": 30, "good": 15, "average": 0, "fringe": -15}.get(tier, 0)
        if (req.property_type.value, req.sub_type.value) in STANDARD_CONFIGS:
            score += 10
        if city in METRO_CITIES or req.city in METRO_CITIES:
            score += 8
        score += {"new": 10, "mid_new": 5, "mid_age": -5, "old": -15,
                  "very_old": -22, "dilapidated": -30}.get(vintage_label, 0)
        if req.legal_status == LegalStatus.freehold:
            score += 8
        elif req.legal_status == LegalStatus.leasehold:
            rem = req.lease_years_remaining or 30
            score += -25 if rem < 15 else -12 if rem < 30 else -3
        else:
            score -= 5
        if rental_yield_pct:
            score += 8 if rental_yield_pct >= 3.0 else 4 if rental_yield_pct >= 1.5 else -3
        infra_count = sum(1 for a in ["near_metro","near_highway","near_hospital","near_school"]
                          if getattr(req, a, None) is True)
        score += infra_count * 4
        if req.planned_area: score += 5
        if req.property_type == PropertyType.industrial: score -= 15
        score += 5 if req.occupancy == OccupancyStatus.rented else -5 if req.occupancy == OccupancyStatus.vacant else 0
        return max(0, min(100, score))

    def _time_to_liquidate(self, rpi, prop_type, city):
        base = {"residential": 60, "commercial": 120, "industrial": 180}.get(prop_type, 90)
        if rpi >= 80:   t_min, t_max = int(base*.3), int(base*.6)
        elif rpi >= 65: t_min, t_max = int(base*.5), int(base*.9)
        elif rpi >= 50: t_min, t_max = int(base*.8), int(base*1.3)
        elif rpi >= 35: t_min, t_max = int(base*1.2), int(base*2.0)
        else:           t_min, t_max = int(base*2.0), int(base*3.5)
        if city in METRO_CITIES:
            t_min = max(7, int(t_min * 0.8))
            t_max = max(14, int(t_max * 0.85))
        return t_min, t_max

    def _base_confidence(self, req, tier, city):
        conf = 0.55
        if tier in ("prime", "good"): conf += 0.12
        if city in METRO_CITIES:      conf += 0.08
        optional = [req.lat, req.floor, req.legal_status.value != "unknown",
                    req.monthly_rent_inr, req.near_metro, req.planned_area,
                    req.parking_available, req.lift_available]
        conf += sum(1 for f in optional if f is not None and f is not False) * 0.02
        if req.legal_status != LegalStatus.unknown: conf += 0.05
        return min(conf, 0.92)


valuation_engine = ValuationEngine()
