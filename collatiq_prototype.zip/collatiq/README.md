# CollatIQ 🏠
### AI-Powered Collateral Valuation & Resale Liquidity Engine
*Poonawalla Fincorp Hackathon · Problem Statement 4A*

---

## What It Does

CollatIQ is a market-aware collateral intelligence API for NBFCs and secured lenders. Given a property's address, type, size, and age it returns:

| Output | Description |
|--------|-------------|
| **Market Value Range** | ₹ min–max based on circle rate + location + attributes |
| **Distress Sale Value** | Market value × liquidity discount |
| **Resale Potential Index** | 0–100 consolidated liquidity score |
| **Time to Liquidate** | Days range (not a point estimate) |
| **Confidence Score** | 0.0–1.0 model certainty |
| **Key Drivers** | Top factors pushing value up |
| **Risk Flags** | Factors reducing value or liquidity |
| **Fraud Flags** | Input validation issues detected |

---

## Quick Start

```bash
git clone https://github.com/[team]/collatiq
cd collatiq
pip install -r requirements.txt
uvicorn app.main:app --reload
```

API is now live at **http://localhost:8000**
- Interactive docs: **http://localhost:8000/docs**
- Example run: **http://localhost:8000/api/v1/valuate/example**

---

## Example Request

```bash
curl -X POST http://localhost:8000/api/v1/valuate \
  -H "Content-Type: application/json" \
  -d '{
    "address": "Koregaon Park, Pune",
    "city": "Pune",
    "property_type": "residential",
    "sub_type": "apartment",
    "carpet_area_sqft": 850,
    "vintage_years": 8,
    "floor": 4,
    "total_floors": 12,
    "lift_available": true,
    "legal_status": "freehold",
    "occupancy": "rented",
    "monthly_rent_inr": 28000,
    "near_metro": true,
    "planned_area": true
  }'
```

### Example Response

```json
{
  "market_value_range": [8075000, 9647500],
  "distress_value_range": [6461250, 7140000],
  "resale_potential_index": 90,
  "liquidity_band": "Highly Liquid",
  "time_to_sell_days": [18, 34],
  "confidence_score": 0.87,
  "key_drivers": [
    "prime_koregaon_park_location",
    "metro_city_liquidity_premium",
    "proximity_to_metro",
    "income_generating_asset",
    "rental_yield_2.09pct",
    "parking_availability_premium"
  ],
  "risk_flags": ["age_8yr_depreciation"],
  "fraud_flags": [],
  "price_per_sqft": 10437,
  "circle_rate_benchmark_psf": 9500,
  "rental_yield_pct": 2.09,
  "distress_discount_pct": 18.0,
  "valuation_methodology": "circle_rate(9500₹/sqft) × area(850sqft) × type(1.00) × infra(1.17) × dep(0.93)"
}
```

---

## API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| `POST` | `/api/v1/valuate` | Main valuation endpoint |
| `GET`  | `/api/v1/valuate/example` | Run built-in example |
| `GET`  | `/api/v1/valuate/cities` | Supported cities list |
| `POST` | `/api/v1/valuate/compare` | Side-by-side comparison |
| `GET`  | `/health` | Health check |

---

## Architecture

```
Request → Input Validation (Fraud Layer) → Feature Engineering → Valuation Engine → Output
              ↓                                    ↓                     ↓
         FraudFlags                        LocationResolver         MarketValue
         ConfidencePenalty                 InfraMultiplier          DistressValue
                                           DepreciationCalc         ResaleIndex
                                           RentalYieldSignal        TimeToLiquidate
                                                                     ConfidenceScore
```

### Valuation Formula
```
V = circle_rate_psf × area × property_type_mult × infra_mult × depreciation_factor
market_value_range = [V × 0.95, V × 1.05]
distress_value = V × (1 − liquidity_discount)
```

### Resale Potential Index (RPI)
```
RPI = 50 (base)
    + location_score   (prime +30, good +15, fringe -15)
    + config_score     (standard config +10)
    + metro_bonus      (+8)
    + age_score        (new +10, very_old -22)
    + legal_score      (freehold +8, short_lease -25)
    + yield_score      (strong +8)
    + infra_score      (per facility +4)
```

---

## Fraud Detection

Every request runs 5 validation checks before the valuation pipeline:

1. **SIZE_OVERSTATED** — Carpet area > P99 norm for sub-type
2. **SIZE_UNDERSTATED** — Carpet area < minimum norm
3. **TYPE_LOCATION_MISMATCH** — Industrial address + residential type (or vice versa)
4. **LEASE_SHORT_TENURE** — Leasehold < 15 years remaining
5. **CONFIG_IMPLAUSIBLE** — e.g. 4BHK < 600 sqft
6. **FLOOR_EXCEEDS_TOTAL** — Floor number > total floors

---

## Supported Cities

Mumbai · Delhi · Bengaluru · Pune · Hyderabad · Chennai · Kolkata · Ahmedabad · Noida · Gurgaon
*(+ default tier for all other cities)*

---

## Running Tests

```bash
pytest tests/ -v
```

---

## Tech Stack

- **Python 3.11+**
- **FastAPI** — REST API framework
- **Pydantic v2** — Data validation
- **Uvicorn** — ASGI server

## Deploy to Render

1. Fork this repo
2. Create a new Web Service on [render.com](https://render.com)
3. Build command: `pip install -r requirements.txt`
4. Start command: `uvicorn app.main:app --host 0.0.0.0 --port $PORT`

---

*Built for Poonawalla Fincorp Hackathon 2024 · Problem Statement 4A*
