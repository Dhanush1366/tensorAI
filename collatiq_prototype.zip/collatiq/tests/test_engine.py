"""
CollatIQ Test Suite
Tests cover: valuation engine, fraud detection, edge cases.
Run: python -m pytest tests/ -v
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from app.models import ValuationRequest, PropertyType, LegalStatus, OccupancyStatus
from app.fraud  import run_fraud_checks
from app.engine import valuate

# ── helpers ──────────────────────────────────────────────────────────────────
def base_req(**overrides) -> ValuationRequest:
    defaults = dict(
        city="Pune", locality="Koregaon Park",
        property_type="residential", sub_type="apartment",
        carpet_area_sqft=850, vintage_years=8,
        floor=4, lift_available=True, parking=True,
        legal_status="freehold", occupancy="rented", monthly_rent=28000,
        nearby_metro=True, nearby_it_hub=False,
    )
    defaults.update(overrides)
    return ValuationRequest(**defaults)

def run(req):
    flags, penalty = run_fraud_checks(req)
    return valuate(req, flags, penalty), flags

# ── Test 1: Basic sanity ──────────────────────────────────────────────────────
def test_basic_valuation():
    res, flags = run(base_req())
    assert res.market_value_range.low > 0
    assert res.market_value_range.high > res.market_value_range.low
    assert res.distress_value_range.low < res.market_value_range.low
    assert 0 <= res.resale_potential_index <= 100
    assert 0.0 <= res.confidence_score <= 1.0
    print(f"  Market: {res.market_value_range.label}")
    print(f"  RPI:    {res.resale_potential_index}  Confidence: {res.confidence_score}")

# ── Test 2: Mumbai premium vs Tier-3 city ─────────────────────────────────────
def test_city_tier_premium():
    pune_res, _   = run(base_req(city="Pune",    locality="Koregaon Park"))
    mumbai_res, _ = run(base_req(city="Mumbai",  locality="Bandra"))
    tier3_res, _  = run(base_req(city="Nagpur",  locality="some area"))
    assert mumbai_res.market_value_range.low > pune_res.market_value_range.low
    assert pune_res.market_value_range.low   > tier3_res.market_value_range.low
    print(f"  Mumbai: {mumbai_res.market_value_range.label}")
    print(f"  Pune:   {pune_res.market_value_range.label}")
    print(f"  Nagpur: {tier3_res.market_value_range.label}")

# ── Test 3: Depreciation effect ───────────────────────────────────────────────
def test_depreciation():
    new_res,  _ = run(base_req(vintage_years=2))
    mid_res,  _ = run(base_req(vintage_years=15))
    old_res,  _ = run(base_req(vintage_years=40))
    assert new_res.market_value_range.low > mid_res.market_value_range.low
    assert mid_res.market_value_range.low > old_res.market_value_range.low
    print(f"  New (2yr):  {new_res.market_value_range.label}")
    print(f"  Mid (15yr): {mid_res.market_value_range.label}")
    print(f"  Old (40yr): {old_res.market_value_range.label}")

# ── Test 4: Distress always < market ─────────────────────────────────────────
def test_distress_less_than_market():
    res, _ = run(base_req())
    assert res.distress_value_range.high < res.market_value_range.high
    assert res.distress_value_range.low  < res.market_value_range.low
    print(f"  Market:   {res.market_value_range.label}")
    print(f"  Distress: {res.distress_value_range.label}")

# ── Test 5: Fraud — type mismatch ─────────────────────────────────────────────
def test_fraud_type_mismatch():
    req = base_req(property_type="residential", sub_type="warehouse")
    flags, penalty = run_fraud_checks(req)
    codes = [f.code for f in flags]
    assert "TYPE_SUBTYPE_MISMATCH" in codes
    print(f"  Fraud flags: {codes}")

# ── Test 6: Fraud — overstated area ──────────────────────────────────────────
def test_fraud_overstated_area():
    req = base_req(carpet_area_sqft=9000)  # apartment >> P90
    flags, penalty = run_fraud_checks(req)
    codes = [f.code for f in flags]
    assert "AREA_OVERSTATED" in codes
    print(f"  Fraud flags: {codes}  Penalty: {penalty:.2f}")

# ── Test 7: Leasehold short tenure ───────────────────────────────────────────
def test_leasehold_short():
    req = base_req(legal_status="leasehold", leasehold_years_remaining=10)
    flags, penalty = run_fraud_checks(req)
    codes = [f.code for f in flags]
    assert "LEASEHOLD_SHORT_TENURE" in codes
    res, _ = run(req)
    assert res.liquidity_discount_pct > 25  # bigger discount
    print(f"  Discount: {res.liquidity_discount_pct}%  RPI: {res.resale_potential_index}")

# ── Test 8: Metro proximity raises RPI ───────────────────────────────────────
def test_metro_raises_rpi():
    no_metro,  _ = run(base_req(nearby_metro=False, nearby_it_hub=False))
    with_metro, _ = run(base_req(nearby_metro=True,  nearby_it_hub=False))
    assert with_metro.resale_potential_index > no_metro.resale_potential_index
    print(f"  Without metro: {no_metro.resale_potential_index}  With metro: {with_metro.resale_potential_index}")

# ── Test 9: Commercial property ───────────────────────────────────────────────
def test_commercial():
    req = base_req(property_type="commercial", sub_type="office", carpet_area_sqft=1200, monthly_rent=None)
    res, flags = run(req)
    assert res.market_value_range.low > 0
    print(f"  Commercial office: {res.market_value_range.label}  RPI: {res.resale_potential_index}")

# ── Test 10: Rental yield signal ──────────────────────────────────────────────
def test_rental_yield():
    res, _ = run(base_req(monthly_rent=30000))
    assert res.rental_yield_pct is not None
    assert res.rental_yield_pct > 0
    print(f"  Rental yield: {res.rental_yield_pct}%")

# ── Test 11: Warehouse illiquid ───────────────────────────────────────────────
def test_warehouse_illiquid():
    req = base_req(property_type="commercial", sub_type="warehouse", carpet_area_sqft=5000, monthly_rent=None)
    res, _ = run(req)
    assert res.resale_potential_index < 60
    print(f"  Warehouse RPI: {res.resale_potential_index}  Band: {res.liquidity_band}")

# ── Test 12: Confidence improves with more data ───────────────────────────────
def test_confidence_improves():
    sparse = base_req(legal_status="unknown", monthly_rent=None, amenity_score=None)
    rich   = base_req(legal_status="freehold", monthly_rent=28000, amenity_score=8, lat=18.5, lng=73.8)
    sparse_res, _ = run(sparse)
    rich_res,   _ = run(rich)
    assert rich_res.confidence_score > sparse_res.confidence_score
    print(f"  Sparse: {sparse_res.confidence_score}  Rich: {rich_res.confidence_score}")


if __name__ == "__main__":
    tests = [
        ("Basic Valuation",           test_basic_valuation),
        ("City Tier Premium",          test_city_tier_premium),
        ("Depreciation Effect",        test_depreciation),
        ("Distress < Market",          test_distress_less_than_market),
        ("Fraud: Type Mismatch",       test_fraud_type_mismatch),
        ("Fraud: Overstated Area",     test_fraud_overstated_area),
        ("Leasehold Short Tenure",     test_leasehold_short),
        ("Metro Raises RPI",           test_metro_raises_rpi),
        ("Commercial Property",        test_commercial),
        ("Rental Yield Signal",        test_rental_yield),
        ("Warehouse Illiquid",         test_warehouse_illiquid),
        ("Confidence Improves",        test_confidence_improves),
    ]
    passed = 0
    for name, fn in tests:
        try:
            print(f"\n✅ {name}")
            fn()
            passed += 1
        except AssertionError as e:
            print(f"❌ FAILED: {e}")
        except Exception as e:
            print(f"💥 ERROR:  {e}")
    print(f"\n{'='*40}")
    print(f"Results: {passed}/{len(tests)} tests passed")
