"""
CollatIQ — AI-Powered Collateral Valuation & Resale Liquidity Engine
FastAPI application entry point
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import ValidationError
import time

from app.models   import ValuationRequest, ValuationResponse
from app.fraud    import run_fraud_checks
from app.engine   import valuate

# ── App init ──────────────────────────────────────────────────────────────────
app = FastAPI(
    title="CollatIQ",
    description=(
        "AI-Powered Collateral Valuation & Resale Liquidity Engine for NBFCs.\n\n"
        "Produces: Market Value Range · Distress Value · Resale Potential Index · "
        "Time-to-Liquidate · Confidence Score · Fraud Flags."
    ),
    version="1.0.0",
    contact={"name": "CollatIQ Team", "email": "team@collatiq.dev"},
    license_info={"name": "MIT"},
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


# ── Middleware: request timing ─────────────────────────────────────────────────
@app.middleware("http")
async def add_timing(request: Request, call_next):
    t0 = time.time()
    resp = await call_next(request)
    resp.headers["X-Response-Time"] = f"{(time.time()-t0)*1000:.1f}ms"
    return resp


# ── Health ────────────────────────────────────────────────────────────────────
@app.get("/health", tags=["System"])
def health():
    return {"status": "ok", "service": "CollatIQ v1.0"}


# ══════════════════════════════════════════════════════════════════════════════
# MAIN ENDPOINT: POST /api/v1/valuate
# ══════════════════════════════════════════════════════════════════════════════
@app.post(
    "/api/v1/valuate",
    response_model=ValuationResponse,
    summary="Valuate a property",
    description=(
        "Submit property details to receive a full collateral intelligence report: "
        "market value range, distress value, resale potential index (0–100), "
        "time-to-liquidate estimate, confidence score, and fraud flags."
    ),
    tags=["Valuation"],
    responses={
        200: {"description": "Valuation complete"},
        400: {"description": "Validation or fraud block"},
        422: {"description": "Request schema error"},
    },
)
def valuate_property(req: ValuationRequest):
    # ── Step 1: Fraud & Validation ────────────────────────────────────────
    fraud_flags, fraud_penalty = run_fraud_checks(req)

    # Hard block on HIGH severity type mismatch
    hard_blocks = [f for f in fraud_flags if f.code == "TYPE_SUBTYPE_MISMATCH"]
    if hard_blocks:
        raise HTTPException(
            status_code=400,
            detail={
                "error": "VALIDATION_FAILED",
                "message": hard_blocks[0].description,
                "action": hard_blocks[0].action,
                "fraud_flags": [f.model_dump() for f in fraud_flags],
            }
        )

    # ── Step 2: Clamp area if overstated ─────────────────────────────────
    from app.fraud import AREA_NORMS
    sub = req.sub_type.lower().strip()
    norms = AREA_NORMS.get(sub, AREA_NORMS["apartment"])
    _, _, _, p90 = norms
    if req.carpet_area_sqft > p90:
        req.carpet_area_sqft = float(p90)

    # ── Step 3: Core valuation ────────────────────────────────────────────
    result = valuate(req, fraud_flags, fraud_penalty)
    return result


# ══════════════════════════════════════════════════════════════════════════════
# BATCH ENDPOINT: POST /api/v1/valuate/batch
# ══════════════════════════════════════════════════════════════════════════════
@app.post(
    "/api/v1/valuate/batch",
    summary="Batch valuate up to 20 properties",
    tags=["Valuation"],
)
def valuate_batch(requests: list[ValuationRequest]):
    if len(requests) > 20:
        raise HTTPException(status_code=400, detail="Batch limit is 20 properties per request.")
    results = []
    for i, req in enumerate(requests):
        try:
            fraud_flags, fraud_penalty = run_fraud_checks(req)
            from app.fraud import AREA_NORMS
            sub = req.sub_type.lower().strip()
            _, _, _, p90 = AREA_NORMS.get(sub, AREA_NORMS["apartment"])
            if req.carpet_area_sqft > p90:
                req.carpet_area_sqft = float(p90)
            result = valuate(req, fraud_flags, fraud_penalty)
            results.append({"index": i, "status": "ok", "result": result.model_dump()})
        except Exception as e:
            results.append({"index": i, "status": "error", "error": str(e)})
    return {"count": len(results), "results": results}


# ══════════════════════════════════════════════════════════════════════════════
# EXPLAIN ENDPOINT: POST /api/v1/explain
# ══════════════════════════════════════════════════════════════════════════════
@app.post(
    "/api/v1/explain",
    summary="Get a plain-English explanation of the valuation",
    tags=["Valuation"],
)
def explain_valuation(req: ValuationRequest):
    fraud_flags, fraud_penalty = run_fraud_checks(req)
    from app.fraud import AREA_NORMS
    sub = req.sub_type.lower().strip()
    _, _, _, p90 = AREA_NORMS.get(sub, AREA_NORMS["apartment"])
    if req.carpet_area_sqft > p90:
        req.carpet_area_sqft = float(p90)
    r = valuate(req, fraud_flags, fraud_penalty)

    lines = [
        f"## CollatIQ Valuation Report",
        f"**Property**: {req.sub_type.title()} in {req.locality}, {req.city}",
        f"**Size**: {int(req.carpet_area_sqft)} sqft  |  **Age**: {req.vintage_years} years",
        f"",
        f"### Market Value Estimate",
        f"The property's estimated market value is **{r.market_value_range.label}**.",
        f"This is based on a circle rate of ₹{r.circle_rate_per_sqft:,}/sqft, "
        f"a location premium of {r.location_premium_pct:+.1f}%, "
        f"and a depreciation factor of {r.depreciation_factor:.2f}.",
        f"",
        f"### In a Forced Sale Scenario",
        f"Under distress conditions, the likely realisation is **{r.distress_value_range.label}** "
        f"(discount of {r.liquidity_discount_pct}% applied).",
        f"",
        f"### Liquidity Assessment",
        f"The Resale Potential Index (RPI) is **{r.resale_potential_index}/100** — {r.liquidity_band.value}.",
        f"Expected time to sell: **{r.time_to_sell_days['min']}–{r.time_to_sell_days['max']} days**.",
        f"{r.time_to_sell_days['label']}.",
        f"",
        f"### Confidence",
        f"Model confidence: **{r.confidence_score:.0%}**. "
        + ("Providing more optional fields (lat/lng, rental details, amenity score) improves accuracy." if r.confidence_score < 0.80 else "Good data quality."),
        f"",
        f"### Key Value Drivers",
    ] + [f"- {d.replace('_',' ').title()}" for d in r.key_drivers] + [
        f"",
        f"### Risk Flags",
    ] + ([f"- {rf.replace('_',' ').title()}" for rf in r.risk_flags] if r.risk_flags else ["- None identified"]) + [
        f"",
        f"---",
        f"*{r.disclaimer}*",
    ]

    return {"report": "\n".join(lines), "valuation": r.model_dump()}


# ══════════════════════════════════════════════════════════════════════════════
# DASHBOARD UI
# ══════════════════════════════════════════════════════════════════════════════
@app.get("/", response_class=HTMLResponse, include_in_schema=False)
def dashboard():
    return HTMLResponse(DASHBOARD_HTML)


DASHBOARD_HTML = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>CollatIQ — Collateral Valuation Engine</title>
<style>
  :root {
    --ink: #0A1628; --navy: #102244; --teal: #0D7377; --mint: #14BDAC;
    --gold: #F0A500; --white: #fff; --panel: #EBF1F8; --muted: #7A8FA6;
    --red: #D64045; --green: #1B8A5A; --amber: #E07B20;
  }
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { font-family: 'Segoe UI', system-ui, sans-serif; background: var(--panel); color: var(--ink); min-height: 100vh; }

  /* NAV */
  nav { background: var(--ink); padding: 14px 32px; display:flex; align-items:center; justify-content:space-between; }
  .logo { font-size: 24px; font-weight: 900; color: var(--gold); letter-spacing: -0.5px; }
  .logo span { color: var(--mint); }
  .nav-tag { background: var(--teal); color: var(--white); font-size: 10px; font-weight: 700; padding: 3px 10px; border-radius: 20px; letter-spacing: 1px; }

  /* LAYOUT */
  .container { max-width: 1200px; margin: 0 auto; padding: 28px 24px; display: grid; grid-template-columns: 1fr 1fr; gap: 24px; }
  @media(max-width:820px){ .container{ grid-template-columns:1fr; } }

  /* CARDS */
  .card { background: var(--white); border-radius: 12px; padding: 24px; box-shadow: 0 2px 16px rgba(10,22,40,.10); }
  .card-title { font-size: 13px; font-weight: 700; text-transform: uppercase; letter-spacing: 1.2px; color: var(--muted); margin-bottom: 18px; }
  .card-title.accent { color: var(--teal); }

  /* FORM */
  .form-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
  .form-grid.full { grid-template-columns: 1fr; }
  label { font-size: 11px; font-weight: 600; color: var(--muted); display: block; margin-bottom: 4px; text-transform: uppercase; letter-spacing: .7px; }
  input, select { width: 100%; padding: 9px 12px; border: 1.5px solid #D1DCEA; border-radius: 7px; font-size: 13px; color: var(--ink); background: var(--white); transition: border .2s; }
  input:focus, select:focus { outline: none; border-color: var(--teal); }
  .toggle-row { display:flex; align-items:center; gap:8px; margin-top:4px; }
  .toggle-row label { margin:0; font-size:12px; color:var(--ink); text-transform:none; letter-spacing:0; }
  input[type=checkbox] { width:16px; height:16px; accent-color:var(--teal); }
  .section-label { font-size:11px; font-weight:700; text-transform:uppercase; letter-spacing:1px; color:var(--navy); margin:16px 0 8px; padding-bottom:4px; border-bottom:2px solid var(--panel); }

  /* BUTTON */
  .btn { background: var(--teal); color: var(--white); font-weight: 700; font-size: 15px; padding: 13px 24px; border: none; border-radius: 8px; cursor: pointer; width: 100%; margin-top: 16px; transition: background .2s; letter-spacing: .3px; }
  .btn:hover { background: #0a5f63; }
  .btn:disabled { background: var(--muted); cursor: not-allowed; }

  /* RESULTS */
  .result-panel { display: none; }
  .kpi-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-bottom: 16px; }
  .kpi { border-radius: 10px; padding: 16px; position: relative; overflow: hidden; }
  .kpi-label { font-size: 10px; font-weight: 700; text-transform: uppercase; letter-spacing: 1px; opacity: .75; margin-bottom: 6px; }
  .kpi-value { font-size: 22px; font-weight: 800; line-height: 1.1; }
  .kpi-sub   { font-size: 10px; opacity: .7; margin-top: 4px; }
  .kpi.navy  { background: var(--navy); color: var(--white); }
  .kpi.teal  { background: var(--teal); color: var(--white); }
  .kpi.gold  { background: var(--gold); color: var(--ink); }
  .kpi.green { background: var(--green); color: var(--white); }
  .kpi.amber { background: var(--amber); color: var(--white); }
  .kpi.red   { background: var(--red); color: var(--white); }

  /* RPI bar */
  .rpi-wrap { margin: 16px 0; }
  .rpi-track { background: #dce8f5; border-radius: 99px; height: 14px; position:relative; }
  .rpi-fill  { height: 14px; border-radius: 99px; transition: width .6s ease; }
  .rpi-labels { display:flex; justify-content:space-between; font-size:10px; color:var(--muted); margin-top:4px; }

  /* Drivers / Risks */
  .chip-row { display:flex; flex-wrap:wrap; gap:6px; margin-top:8px; }
  .chip { font-size: 11px; font-weight: 600; padding: 4px 10px; border-radius: 20px; }
  .chip.driver { background: #d4f0eb; color: var(--green); }
  .chip.risk   { background: #fdecea; color: var(--red); }
  .chip.fraud-high   { background: var(--red); color: var(--white); }
  .chip.fraud-medium { background: var(--amber); color: var(--white); }
  .chip.fraud-low    { background: #7A8FA6; color: var(--white); }

  /* Fraud */
  .fraud-item { background: #fff5f5; border-left: 4px solid var(--red); border-radius: 0 8px 8px 0; padding: 10px 14px; margin: 8px 0; font-size: 12px; }
  .fraud-item.MEDIUM { border-color: var(--amber); background: #fff9f0; }
  .fraud-item.LOW    { border-color: var(--muted); background: #f7f9fc; }
  .fraud-title { font-weight: 700; color: var(--ink); margin-bottom: 3px; }
  .fraud-action { color: var(--muted); font-size: 11px; }

  /* Confidence arc */
  .conf-wrap { text-align:center; margin: 8px 0; }
  .conf-score { font-size: 38px; font-weight: 800; color: var(--teal); }
  .conf-label { font-size: 11px; color: var(--muted); margin-top: 2px; }

  /* Error */
  .error-box { background: #fff0f0; border: 1.5px solid var(--red); border-radius: 8px; padding: 14px; color: var(--red); font-size: 13px; margin-top: 12px; }

  /* Loading */
  .loader { display:none; text-align:center; padding:24px; color:var(--muted); }
  @keyframes spin { to { transform:rotate(360deg); } }
  .spinner { width:32px; height:32px; border:3px solid #dce8f5; border-top-color:var(--teal); border-radius:50%; animation:spin .7s linear infinite; margin:0 auto 10px; }

  .divider { height:1px; background:var(--panel); margin: 14px 0; }
  .full-span { grid-column: 1 / -1; }
  .raw-toggle { font-size:11px; color:var(--teal); cursor:pointer; text-decoration:underline; margin-top:8px; display:block; }
  pre { background:var(--ink); color:var(--mint); border-radius:8px; padding:14px; font-size:10.5px; overflow-x:auto; white-space:pre-wrap; margin-top:8px; display:none; max-height:300px; }
</style>
</head>
<body>

<nav>
  <div class="logo">Collat<span>IQ</span></div>
  <div style="display:flex;gap:12px;align-items:center;">
    <span style="color:#7A8FA6;font-size:12px;">AI Collateral Intelligence</span>
    <span class="nav-tag">v1.0 PROTOTYPE</span>
    <a href="/docs" style="color:var(--mint);font-size:12px;text-decoration:none;">API Docs →</a>
  </div>
</nav>

<div class="container">

  <!-- LEFT: INPUT FORM -->
  <div>
    <div class="card">
      <div class="card-title accent">Property Input</div>

      <div class="section-label">📍 Location</div>
      <div class="form-grid">
        <div><label>City *</label><input id="city" value="Pune" placeholder="e.g. Pune"></div>
        <div><label>Locality *</label><input id="locality" value="Koregaon Park" placeholder="e.g. Koregaon Park"></div>
      </div>
      <div style="margin-top:10px"><label>Full Address (optional)</label><input id="address" placeholder="Street, landmark…"></div>

      <div class="section-label">🏠 Property Details</div>
      <div class="form-grid">
        <div>
          <label>Property Type *</label>
          <select id="property_type">
            <option value="residential">Residential</option>
            <option value="commercial">Commercial</option>
            <option value="industrial">Industrial</option>
          </select>
        </div>
        <div>
          <label>Sub Type *</label>
          <select id="sub_type">
            <option value="apartment">Apartment</option>
            <option value="villa">Villa</option>
            <option value="studio">Studio</option>
            <option value="penthouse">Penthouse</option>
            <option value="row_house">Row House</option>
            <option value="plot">Plot</option>
            <option value="shop">Shop</option>
            <option value="office">Office</option>
            <option value="showroom">Showroom</option>
            <option value="warehouse">Warehouse</option>
            <option value="mixed_use">Mixed Use</option>
          </select>
        </div>
        <div><label>Carpet Area (sqft) *</label><input id="carpet_area_sqft" type="number" value="850" min="1"></div>
        <div><label>Age of Property (years) *</label><input id="vintage_years" type="number" value="8" min="0" max="100"></div>
        <div><label>Floor Number</label><input id="floor" type="number" value="4" min="0"></div>
        <div><label>Total Floors</label><input id="total_floors" type="number" value="12" min="1"></div>
      </div>

      <div class="section-label">⚖️ Legal & Occupancy</div>
      <div class="form-grid">
        <div>
          <label>Legal Status</label>
          <select id="legal_status">
            <option value="freehold">Freehold</option>
            <option value="leasehold">Leasehold</option>
            <option value="unknown">Unknown</option>
          </select>
        </div>
        <div>
          <label>Occupancy</label>
          <select id="occupancy">
            <option value="rented">Rented</option>
            <option value="self_occupied">Self Occupied</option>
            <option value="vacant">Vacant</option>
          </select>
        </div>
        <div><label>Monthly Rent (₹)</label><input id="monthly_rent" type="number" value="28000" min="0"></div>
        <div><label>Amenity Score (0–10)</label><input id="amenity_score" type="number" value="7" min="0" max="10"></div>
      </div>

      <div class="section-label">🏗️ Features & Proximity</div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;">
        <div class="toggle-row"><input type="checkbox" id="lift_available" checked><label for="lift_available">Lift Available</label></div>
        <div class="toggle-row"><input type="checkbox" id="parking" checked><label for="parking">Parking</label></div>
        <div class="toggle-row"><input type="checkbox" id="gated_society"><label for="gated_society">Gated Society</label></div>
        <div class="toggle-row"><input type="checkbox" id="nearby_metro" checked><label for="nearby_metro">Metro Within 1km</label></div>
        <div class="toggle-row"><input type="checkbox" id="nearby_highway"><label for="nearby_highway">Highway Within 2km</label></div>
        <div class="toggle-row"><input type="checkbox" id="nearby_it_hub"><label for="nearby_it_hub">IT Hub Within 3km</label></div>
      </div>

      <button class="btn" id="valuateBtn" onclick="runValuation()">⚡ Valuate Property</button>
      <div id="errorBox"></div>
    </div>
  </div>

  <!-- RIGHT: RESULTS -->
  <div>
    <div class="card" id="placeholderCard">
      <div style="text-align:center;padding:48px 24px;color:var(--muted);">
        <div style="font-size:48px;margin-bottom:16px;">🏢</div>
        <div style="font-size:18px;font-weight:700;color:var(--navy);margin-bottom:8px;">CollatIQ Ready</div>
        <div style="font-size:13px;line-height:1.6;">Fill in the property details on the left<br>and click <strong>Valuate Property</strong> to get<br>a full collateral intelligence report.</div>
        <div style="margin-top:24px;padding:16px;background:var(--panel);border-radius:10px;text-align:left;">
          <div style="font-size:11px;font-weight:700;color:var(--teal);margin-bottom:8px;">YOU'LL RECEIVE:</div>
          <div style="font-size:12px;color:var(--ink);line-height:2;">
            📊 Market Value Range (₹)<br>
            🔴 Distress Sale Value (₹)<br>
            💧 Resale Potential Index (0–100)<br>
            ⏱️ Time to Liquidate (days)<br>
            🎯 Confidence Score<br>
            🚨 Fraud & Risk Flags
          </div>
        </div>
      </div>
    </div>

    <div class="loader" id="loader"><div class="spinner"></div><div>Running CollatIQ engine…</div></div>

    <div class="result-panel card" id="resultPanel">
      <div class="card-title accent">Valuation Report</div>
      <div id="propertyLabel" style="font-size:13px;color:var(--muted);margin-bottom:16px;"></div>

      <div class="kpi-grid" id="kpiGrid"></div>

      <div class="rpi-wrap">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px;">
          <span style="font-size:12px;font-weight:700;color:var(--navy);">Resale Potential Index</span>
          <span id="rpiScore" style="font-size:20px;font-weight:800;color:var(--teal);"></span>
        </div>
        <div class="rpi-track"><div class="rpi-fill" id="rpiFill"></div></div>
        <div class="rpi-labels"><span>0 — Illiquid</span><span>50 — Moderate</span><span>100 — Highly Liquid</span></div>
        <div id="liquidityBand" style="font-size:12px;font-weight:600;margin-top:6px;"></div>
      </div>

      <div class="divider"></div>

      <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;">
        <div>
          <div style="font-size:11px;font-weight:700;color:var(--muted);text-transform:uppercase;margin-bottom:8px;">Key Drivers</div>
          <div class="chip-row" id="driversRow"></div>
        </div>
        <div>
          <div style="font-size:11px;font-weight:700;color:var(--muted);text-transform:uppercase;margin-bottom:8px;">Risk Flags</div>
          <div class="chip-row" id="risksRow"></div>
        </div>
      </div>

      <div id="fraudSection" style="display:none;margin-top:16px;">
        <div style="font-size:11px;font-weight:700;color:var(--red);text-transform:uppercase;margin-bottom:8px;">⚠ Fraud / Validation Alerts</div>
        <div id="fraudList"></div>
      </div>

      <div class="divider"></div>

      <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;">
        <div>
          <div style="font-size:11px;font-weight:700;color:var(--muted);text-transform:uppercase;margin-bottom:8px;">Intermediate Signals</div>
          <div id="signals" style="font-size:12px;color:var(--ink);line-height:1.9;"></div>
        </div>
        <div class="conf-wrap">
          <div style="font-size:11px;font-weight:700;color:var(--muted);text-transform:uppercase;margin-bottom:8px;">Model Confidence</div>
          <div class="conf-score" id="confScore"></div>
          <div class="conf-label" id="confLabel"></div>
        </div>
      </div>

      <span class="raw-toggle" onclick="toggleRaw()">View raw JSON ↓</span>
      <pre id="rawJson"></pre>

      <div style="font-size:10px;color:var(--muted);margin-top:14px;line-height:1.6;" id="disclaimer"></div>
    </div>
  </div>

</div>

<script>
function fmt(n){ return '₹'+(n/100000).toFixed(1)+'L'; }
function rpiColor(v){ return v>=80?'#1B8A5A':v>=50?'#E07B20':'#D64045'; }

async function runValuation(){
  const btn=document.getElementById('valuateBtn');
  const errBox=document.getElementById('errorBox');
  errBox.innerHTML='';
  btn.disabled=true; btn.textContent='Valuating…';
  document.getElementById('placeholderCard').style.display='none';
  document.getElementById('loader').style.display='block';
  document.getElementById('resultPanel').style.display='none';

  const rent=parseFloat(document.getElementById('monthly_rent').value)||null;
  const amenity=parseInt(document.getElementById('amenity_score').value);

  const body={
    city:              document.getElementById('city').value,
    locality:          document.getElementById('locality').value,
    address:           document.getElementById('address').value||null,
    property_type:     document.getElementById('property_type').value,
    sub_type:          document.getElementById('sub_type').value,
    carpet_area_sqft:  parseFloat(document.getElementById('carpet_area_sqft').value),
    vintage_years:     parseInt(document.getElementById('vintage_years').value),
    floor:             parseInt(document.getElementById('floor').value)||null,
    total_floors:      parseInt(document.getElementById('total_floors').value)||null,
    legal_status:      document.getElementById('legal_status').value,
    occupancy:         document.getElementById('occupancy').value,
    monthly_rent:      rent,
    amenity_score:     isNaN(amenity)?null:amenity,
    lift_available:    document.getElementById('lift_available').checked,
    parking:           document.getElementById('parking').checked,
    gated_society:     document.getElementById('gated_society').checked,
    nearby_metro:      document.getElementById('nearby_metro').checked,
    nearby_highway:    document.getElementById('nearby_highway').checked,
    nearby_it_hub:     document.getElementById('nearby_it_hub').checked,
  };

  try{
    const resp=await fetch('/api/v1/valuate',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
    const data=await resp.json();
    document.getElementById('loader').style.display='none';
    btn.disabled=false; btn.textContent='⚡ Valuate Property';

    if(!resp.ok){
      errBox.innerHTML=`<div class="error-box"><strong>${data.detail?.error||'Error'}</strong><br>${data.detail?.message||JSON.stringify(data.detail)}</div>`;
      document.getElementById('placeholderCard').style.display='block';
      return;
    }

    renderResult(body, data);
  } catch(e){
    document.getElementById('loader').style.display='none';
    btn.disabled=false; btn.textContent='⚡ Valuate Property';
    errBox.innerHTML=`<div class="error-box">Network error: ${e.message}</div>`;
    document.getElementById('placeholderCard').style.display='block';
  }
}

function renderResult(inp, d){
  document.getElementById('resultPanel').style.display='block';
  document.getElementById('propertyLabel').textContent=
    `${inp.sub_type.charAt(0).toUpperCase()+inp.sub_type.slice(1)} · ${inp.locality}, ${inp.city} · ${inp.carpet_area_sqft} sqft · ${inp.vintage_years} yr old`;

  // KPIs
  const mv=d.market_value_range, dv=d.distress_value_range;
  const kpis=[
    {label:'Market Value',  value:`${fmt(mv.low)} – ${fmt(mv.high)}`, sub:'Estimated range', cls:'navy'},
    {label:'Distress Value',value:`${fmt(dv.low)} – ${fmt(dv.high)}`, sub:`${d.liquidity_discount_pct}% discount`, cls:'amber'},
    {label:'Time to Sell',  value:`${d.time_to_sell_days.min}–${d.time_to_sell_days.max} days`, sub:d.time_to_sell_days.label.split('—')[0].trim(), cls:'teal'},
    {label:'Confidence',    value:`${(d.confidence_score*100).toFixed(0)}%`, sub:'Model confidence', cls:'green'},
  ];
  document.getElementById('kpiGrid').innerHTML=kpis.map(k=>
    `<div class="kpi ${k.cls}"><div class="kpi-label">${k.label}</div><div class="kpi-value">${k.value}</div><div class="kpi-sub">${k.sub}</div></div>`
  ).join('');

  // RPI
  const rpi=d.resale_potential_index;
  document.getElementById('rpiScore').textContent=rpi+' / 100';
  document.getElementById('rpiFill').style.cssText=`width:${rpi}%;background:${rpiColor(rpi)};`;
  document.getElementById('liquidityBand').innerHTML=
    `<span style="color:${rpiColor(rpi)}">${d.liquidity_band}</span>`;

  // Drivers
  document.getElementById('driversRow').innerHTML=
    (d.key_drivers||[]).map(x=>`<span class="chip driver">${x.replace(/_/g,' ')}</span>`).join('');
  document.getElementById('risksRow').innerHTML=
    (d.risk_flags||[]).length
      ? d.risk_flags.map(x=>`<span class="chip risk">${x.replace(/_/g,' ')}</span>`).join('')
      : '<span style="font-size:12px;color:var(--green)">✓ No major risks</span>';

  // Fraud flags
  const ff=d.fraud_flags||[];
  if(ff.length){
    document.getElementById('fraudSection').style.display='block';
    document.getElementById('fraudList').innerHTML=ff.map(f=>
      `<div class="fraud-item ${f.severity}">
        <div class="fraud-title"><span class="chip fraud-${f.severity.toLowerCase()}">${f.severity}</span> ${f.code.replace(/_/g,' ')}</div>
        <div style="font-size:12px;margin:4px 0;">${f.description}</div>
        <div class="fraud-action">Action: ${f.action}</div>
      </div>`
    ).join('');
  } else {
    document.getElementById('fraudSection').style.display='none';
  }

  // Signals
  document.getElementById('signals').innerHTML=[
    `Circle Rate: <strong>₹${d.circle_rate_per_sqft?.toLocaleString()}/sqft</strong>`,
    `Location Premium: <strong>${d.location_premium_pct>0?'+':''}${d.location_premium_pct}%</strong>`,
    `Depreciation Factor: <strong>${d.depreciation_factor}</strong>`,
    d.rental_yield_pct!=null?`Rental Yield: <strong>${d.rental_yield_pct}%</strong>`:'',
  ].filter(Boolean).map(l=>`<div>${l}</div>`).join('');

  // Confidence
  const conf=d.confidence_score;
  document.getElementById('confScore').textContent=(conf*100).toFixed(0)+'%';
  document.getElementById('confLabel').textContent=
    conf>=0.85?'High confidence':conf>=0.70?'Good confidence':'Add more details to improve';
  document.getElementById('confScore').style.color=conf>=0.80?'var(--teal)':conf>=0.65?'var(--amber)':'var(--red)';

  // Raw JSON
  document.getElementById('rawJson').textContent=JSON.stringify(d,null,2);

  // Disclaimer
  document.getElementById('disclaimer').textContent=d.disclaimer;
}

function toggleRaw(){
  const pre=document.getElementById('rawJson');
  pre.style.display=pre.style.display==='none'?'block':'none';
}

// Update sub_type options by property_type
document.getElementById('property_type').addEventListener('change',function(){
  const sel=document.getElementById('sub_type');
  const resSubs=['apartment','villa','studio','penthouse','row_house','plot'];
  const comSubs=['shop','office','showroom','warehouse','mixed_use'];
  const opts=this.value==='residential'?resSubs:comSubs;
  sel.innerHTML=opts.map(o=>`<option value="${o}">${o.charAt(0).toUpperCase()+o.slice(1).replace('_',' ')}</option>`).join('');
});
</script>
</body>
</html>"""
